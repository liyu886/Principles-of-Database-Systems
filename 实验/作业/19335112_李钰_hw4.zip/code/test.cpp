#include<Windows.h>
#include <sql.h> 
#include <sqlext.h> 
#include<sqltypes.h>
#include <iostream>
#include<string>
#include <iomanip>

using namespace std;

 
SQLHENV henv = SQL_NULL_HENV;   //环境句柄
SQLHDBC hdbc = SQL_NULL_HDBC;  //连接句柄
SQLHSTMT hstmt = SQL_NULL_HSTMT; //语句句柄

//连接数据库
void connection();
void print_book_table();
void print_reader_table();
void print_record_table();
//释放空间
void free();

int main(){     
	
	connection();
    cout << endl << "--------------TABLE book------------" << endl;
    print_book_table();
    cout << endl << "------------TABLE reader------------" << endl;
    print_reader_table();
    cout << endl << "------------TABLE record------------" << endl;
    print_record_table();
	return 0;     
}     

void connection(){
    RETCODE retcode;
    retcode = SQLAllocHandle(SQL_HANDLE_ENV, NULL, &henv);    //申请环境
    retcode = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_INTEGER);//设置环境
    retcode = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc); //申请数据库连接  
	retcode = SQLConnect(hdbc, (SQLTCHAR*)("JY2"), SQL_NTS, (SQLTCHAR*)("sa"), SQL_NTS, (SQLTCHAR*)("wakk248651793"), SQL_NTS);

    //判断连接是否成功  
	if((retcode != SQL_SUCCESS) && (retcode != SQL_SUCCESS_WITH_INFO)){       
		cout << "Connect unsuccessfully!" << endl;
	}else{
        cout << "Connect successfully!" << endl;
    }
}

void print_book_table(){
    RETCODE retcode; 
    string str = "select *from book";
    retcode = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);//申请句柄

    retcode = SQLExecDirect(hstmt, (SQLCHAR*)str.c_str(), SQL_NTS);

    if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO)
    {
        SQLCHAR str1[10], str2[25], str3[20], str4[15], str5[30], str6[11], str7[30];
        SQLLEN len_str1, len_str2, len_str3, len_str4, len_str5, len_str6, len_str7;
       
        cout << left << setw(10) << "book id" ;
        cout << left << setw(25) << "book name" ;
        cout << left << setw(20) << "book isbn" ;
        cout << left << setw(15) << "book author" ;
        cout << left << setw(25) << "book publisher" ;
        cout << left << setw(11) << "book price" ;
        cout << left << setw(30) << "interview times" << endl;
        while (SQLFetch(hstmt) != SQL_NO_DATA)
        {
            SQLGetData(hstmt, 1, SQL_C_CHAR, str1, 10, &len_str1);   //获取第一列数据
            SQLGetData(hstmt, 2, SQL_C_CHAR, str2, 25, &len_str2);
            SQLGetData(hstmt, 3, SQL_C_CHAR, str3, 20, &len_str3);
            SQLGetData(hstmt, 4, SQL_C_CHAR, str4, 15, &len_str4);
            SQLGetData(hstmt, 5, SQL_C_CHAR, str5, 25, &len_str5);
            SQLGetData(hstmt, 6, SQL_C_CHAR, str6, 11, &len_str6);
            SQLGetData(hstmt, 7, SQL_C_CHAR, str7, 30, &len_str7);

            
           // cout << left << setw(30) << str1 << "\t" << str2 << "\t" << str3 << "\t" << str4 << "\t" << str5 << "\t" << str6 << "\t" << str7 << endl;
           cout << left << setw(10) << str1 ;
           cout << left << setw(25) << str2 ;
           cout << left << setw(20) << str3 ;
           cout << left << setw(15) << str4 ;
           cout << left << setw(25) << str5 ;
           cout << left << setw(11) << str6 ;
           cout << left << setw(30) << str7 << endl;
           
        }
    }
    free();

}

void print_reader_table(){
    RETCODE retcode; 
    string str = "select *from reader";
    retcode = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);//申请句柄

    retcode = SQLExecDirect(hstmt, (SQLCHAR*)str.c_str(), SQL_NTS);

    if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO)
    {
        SQLCHAR str1[15], str2[15], str3[15], str4[15];
        SQLLEN len_str1, len_str2, len_str3, len_str4;
       
        cout << left << setw(15) << "reader id" ;
        cout << left << setw(15) << "reader name" ;
        cout << left << setw(15) << "reader sex" ;
        cout << left << setw(15) << "reader department" << endl;

        while (SQLFetch(hstmt) != SQL_NO_DATA)
        {
            SQLGetData(hstmt, 1, SQL_C_CHAR, str1, 15, &len_str1);   //获取第一列数据
            SQLGetData(hstmt, 2, SQL_C_CHAR, str2, 15, &len_str2);
            SQLGetData(hstmt, 3, SQL_C_CHAR, str3, 15, &len_str3);
            SQLGetData(hstmt, 4, SQL_C_CHAR, str4, 15, &len_str4);

            cout << left << setw(15) << str1 ;
            cout << left << setw(15) << str2 ;
            cout << left << setw(15) << str3 ;
            cout << left << setw(15) << str4 << endl;
           
        }
    }
    free();

}

void print_record_table(){
    RETCODE retcode; 
    string str = "select *from record";
    retcode = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);//申请句柄

    retcode = SQLExecDirect(hstmt, (SQLCHAR*)str.c_str(), SQL_NTS);

    if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO)
    {
        SQLCHAR str1[15], str2[15], str3[15], str4[15], str5[15];
        SQLLEN len_str1, len_str2, len_str3, len_str4, len_str5;
       
        cout << left << setw(15) << "reader id" ;
        cout << left << setw(15) << "book id" ;
        cout << left << setw(15) << "borrow date" ;
        cout << left << setw(15) << "return date" ;
        cout << left << setw(15) << "notes" << endl;
        
        while (SQLFetch(hstmt) != SQL_NO_DATA)
        {
            SQLGetData(hstmt, 1, SQL_C_CHAR, str1, 15, &len_str1);   //获取第一列数据
            SQLGetData(hstmt, 2, SQL_C_CHAR, str2, 15, &len_str2);
            SQLGetData(hstmt, 3, SQL_C_CHAR, str3, 15, &len_str3);
            SQLGetData(hstmt, 4, SQL_C_CHAR, str4, 15, &len_str4);
            SQLGetData(hstmt, 5, SQL_C_CHAR, str5, 15, &len_str5);
            
            cout << left << setw(15) << str1 ;
            cout << left << setw(15) << str2 ;
            cout << left << setw(15) << str3 ;
            cout << left << setw(15) << str4 ;
            cout << left << setw(15) << str5 << endl;
           
        }
    }
    free();

}

//释放空间
void free()
{
    SQLFreeHandle(SQL_HANDLE_STMT, hstmt);//释放语句
    SQLFreeHandle(SQL_HANDLE_DBC, hdbc);//释放连接
    SQLFreeHandle(SQL_HANDLE_ENV, henv);//释放环境
}
