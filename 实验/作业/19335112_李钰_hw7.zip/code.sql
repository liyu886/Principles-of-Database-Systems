use JY
go

/*
1. ����������
create trigger [dbo].[T1] on [dbo].[record]
for insert, update, delete
as
declare @bookid1 char(10)
select @bookid1 = book_id
from inserted
update book
set interview_times = interview_times + 1
where book_id = @bookid1 

declare @bookid2 char(10)
select @bookid2 = book_id
from deleted
update book
set interview_times = interview_times - 1
where book_id = @bookid2

*/

/*
��record����
INSERT [dbo].[RECORD] ([reader_id], [book_id], [borrow_date], [return_date],[notes]) VALUES ('r0005',	'b0001',	'2014-03-02',	'2014-04-20',NULL)
*/

/*
����recordֵ
update record 
set book_id = 'b0002'
where reader_id = 'r0005'
*/

/*ɾ��������
delete record
where reader_id = 'r0005' and book_id = 'b0002'
*/

/* 2. ����������T2

create trigger T2 on reader
after update
as 
begin
	declare @delete_name char(10)
	declare @new_name char(10)
	declare @delete_id char(5)
	declare @new_id char(5)
	declare @delete_sex char(4)
	declare @new_sex char(4)
	declare @delete_department char(12)
	declare @new_department char(12)
	select @delete_name = reader_name from deleted
	select @new_name = reader_name from inserted
	select @delete_id = reader_id from deleted
	select @new_id = reader_id from inserted
	select @delete_sex = reader_sex from deleted
	select @new_sex = reader_sex from inserted
	select @delete_department = reader_department from deleted
	select @new_department = reader_department from inserted
	print 'Reader_id '+convert(varchar,@delete_id)+' is chanched to '+convert(varchar,@new_id)
	print 'Name '+convert(varchar,@delete_name)+' is chanched to '+convert(varchar,@new_name)
	print 'Reader sex '+convert(varchar,@delete_sex)+' is chanched to '+convert(varchar,@new_sex)
	print 'Department '+convert(varchar,@delete_department)+' is chanched to '+convert(varchar,@new_department)

end


update reader
set reader_name = '��С��', reader_department = '�����ϵ'
where reader_name = '��º�'
*/
/*
3. ����������T3
create trigger T3 on reader
after insert
as begin
	if exists(select* from inserted)
	print 'Cannot insert!'
	rollback transaction
end

insert reader
values('r0010','��С��', 'Ů','�����ϵ')


4. ɾ��������
if exists (select * from sysobjects where name = 'T2')
drop trigger dbo.T2


if exists (select * from sysobjects where name = 'T3')
drop trigger dbo.T3


5. ����������T4
create trigger T4 on reader
after insert, update, delete
as begin
	if exists(select* from deleted)
	print '���޸�reader���ݱ�������'
	else 
	print '������Ҫ�޸ĵ�����'
end



update reader
set reader_name = '��º�'
where reader_name = '��С��'


update reader
set reader_department = '��ѧϵ'
where reader_name = '��С��'
*/
