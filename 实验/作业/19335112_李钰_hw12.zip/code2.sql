use JY 
go
/*
begin tran
update book set interview_times = interview_times - 1
where book_name = 'SQL Server 2012����'
*/

/*
begin tran
update book set interview_times = interview_times - 1
where book_name = 'SQL Server 2012����'

waitfor delay '00:00:20'		--��ʱ20s
select interview_times from book where book_name = 'SQL Server 2012����' 
rollback tran 
*/

set transaction isolation level repeatable read
begin tran
select interview_times from book where book_name = 'SQL Server 2012����'
waitfor delay '00:00:05'
update book set interview_times = interview_times - 1
where book_name = 'SQL Server 2012����'
commit tran
select interview_times from book where book_name = 'SQL Server 2012����'