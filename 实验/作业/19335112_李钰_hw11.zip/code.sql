use JY
go
/*
insert record values('r0001', 'b0001', '2014-10-16', '2014-11-16', NULL)
go

begin tran
update book
set interview_times = interview_times + 1
where book_id = 'b0001'
commit tran
*/

/*
begin tran
declare @my_price money
declare my_cursor cursor for
	select book_price from book
open my_cursor
fetch next from my_cursor into @my_price
while @@FETCH_STATUS = 0
begin 
	if @my_price <= 20
		update book set book_price = book_price + 8 where book_price = @my_price
	if @my_price <= 30 and @my_price >= 20
		update book set book_price = book_price + 4 where book_price = @my_price
	if @my_price > 30
		update book set book_price = book_price - 4 where book_price = @my_price
	fetch next from my_cursor into @my_price
end
close my_cursor
deallocate my_cursor
commit tran
*/

/*
create procedure total_price
as
begin tran
declare @total money
set @total = 0.0
declare @my_price money
declare my_cursor cursor for
	select book_price from book
open my_cursor
fetch next from my_cursor into @my_price
while @@FETCH_STATUS = 0
begin 
	set @total = @total + @my_price
	fetch next from my_cursor into @my_price
end
close my_cursor
deallocate my_cursor
print @total
commit tran
go

exec total_price
go
*/


/*
select sum(book_price)
from book
go
*/
