
use school
SET Statistics PROFILE on;
select CHOICES.SID from CHOICES, COURSES where CHOICES.CID=COURSES.CID and COURSES.CNAME='database';
SET Statistics PROFILE off;
/*
use school;
Go
set showplan_text on;
GO
select CHOICES.SID from CHOICES, COURSES where CHOICES.CID=COURSES.CID and COURSES.CNAME='database';
Go
set showplan_text off;
GO


use school;
Go
SET SHOWPLAN_ALL ON;
GO
select CHOICES.SID from CHOICES, COURSES where CHOICES.CID=COURSES.CID and COURSES.CNAME='database';
Go
SET SHOWPLAN_ALL OFF;
GO


use school
go
create unique index cname_index on courses(cname)
go
SET Statistics PROFILE on;
select CHOICES.SID from CHOICES, COURSES where CHOICES.CID=COURSES.CID and COURSES.CNAME='database';
SET Statistics PROFILE off;
*/