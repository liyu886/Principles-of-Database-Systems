alter table book add total smallint not null

