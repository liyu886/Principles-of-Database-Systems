create table record
(reader_id char(8) not null,
book_id char(8) not null,
borrow_date date not null,
return_date date not null,
notes nvarchar(50) not null)