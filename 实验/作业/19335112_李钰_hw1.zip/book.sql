create table book
(book_id char(8) not null,
book_name char(17) not null,
book_isbn char(17) not null,
book_author nvarchar(10) not null,
book_publisher nvarchar(50) not null,
book_price money not null,
interview_times smallint not null)
