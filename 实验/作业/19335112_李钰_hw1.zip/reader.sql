create table reader 
(reader_id char(8) not null,
reader_name nvarchar(50) not null,
reader_sex char(2) not null,
reader_department nvarchar(60) not null)